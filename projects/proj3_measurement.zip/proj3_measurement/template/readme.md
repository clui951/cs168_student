This directory gives you a LaTeX template for the short answers. 
You can run `make` to compile the latex file into a PDF called `project3.pdf`.
You can clean the directory by calling `make clean`.

You should replace each answer placeholder with your own answer. 
To include a PDF graph, you can use `\includegraphics[scale=0.5]{cdf_graph.pdf}`. 