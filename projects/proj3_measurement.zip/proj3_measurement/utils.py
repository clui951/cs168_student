# json keys for DNS output.
NAME_KEY = "Name"
SUCCESS_KEY = "Success"
TIME_KEY = "Time in millis"
ANSWERS_KEY = "Answers"
QUERIES_KEY = "Queries"
QUERIED_NAME_KEY = "Queried name"
TTL_KEY = "TTL"
TYPE_KEY = "Type"
ANSWER_DATA_KEY = "Data"


